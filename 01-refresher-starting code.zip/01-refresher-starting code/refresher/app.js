const express = require("express");
const bodyParser = require("body-parser");
const mongoPractice = require("./mongoose");

const app = express();

app.use(bodyParser.json());

app.post("/products", mongoPractice.createProduct);

app.get("/products", mongoPractice.getProducts);

app.listen(3000);
//mongodb+srv://d9furj6j:SRL7L79Lu71Tj9aT@cluster0.slshu6y.mongodb.net/?retryWrites=true&w=majority
