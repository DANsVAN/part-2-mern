const mongoose = require("mongoose");

const Product = require("../models/product");

mongoose
  .connect(
    "mongodb+srv://d9furj6j:SRL7L79Lu71Tj9aT@cluster0.slshu6y.mongodb.net/places_test?retryWrites=true&w=majority"
  )
  .then(() => {
    console.log("connected to database");
  })
  .catch(() => {
    console.log("connection failed");
  });

const createProduct = async (req, res, next) => {
  const createProduct = new Product({
    name: req.body.name,
    price: req.body.price,
  });
  const result = await createProduct.save();
  console.log(typeof createProduct.id);
  res.json(result);

  res.json(result);
};
async function getProducts(req, res, next) {
  const products = await Product.find().exec();
  res.json(products);
}

exports.createProduct = createProduct;
exports.getProducts = getProducts;
